//
//  FileManagerExtension.swift
//  MasterMind
//
//  Created by UDLAP19 on 12/1/19.
//  Copyright © 2019 UDLAP19. All rights reserved.
//

import Foundation

public extension FileManager {
    static var documentDirectoryURL: URL {
        return try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
    }
}
