//
//  CustomizeViewController.swift
//  MasterMind
//
//  Created by Carlos Andrés Reyes Evangelista in UDLAP19 on 10/5/19.
//  Copyright © 2019 UDLAP19. All rights reserved.
//

import UIKit

class CustomizeViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    
    @IBOutlet weak var currentCurrencyLabel: UIButton!
    @IBOutlet weak var selectedBallsCounterLabel: UILabel!
    @IBOutlet weak var collection: UICollectionView!
    @IBOutlet weak var notification: UIButton!
    @IBOutlet weak var applyButton: UIButton!
    
    var selectedBalls = getSelectedBalls()
    var lockedBalls = getLockedBalls()
    
    var selectedBallsCounter = 6
    var currentCurrency = getCurrency()
    let pricePerBall = 500
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        currentCurrencyLabel.setTitle("\(currentCurrency)", for: .normal)
        notification.setTitle("\(lockedBalls.isEmpty ? "You have everything already!" : "Select a locked ball to unlock")", for: .normal)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        lockedBalls = getLockedBalls()
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return availableBalls.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        selectedBalls = getSelectedBalls()
        lockedBalls = getLockedBalls()
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as! AvailableBall
        
        cell.ball.image = UIImage(named: availableBalls[indexPath.item])
        if selectedBalls.contains(availableBalls[indexPath.item]) {
            cell.background.image = UIImage(named: "selected")
            cell.chosen = true
        }
        
        if lockedBalls.contains(availableBalls[indexPath.item]) {
            cell.lockedImage.image = UIImage(named: "locked")
            cell.locked = true
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let cell = collection.cellForItem(at: indexPath) as! AvailableBall
        print(indexPath.item)
        
        if cell.chosen {
            cell.chosen.toggle()
            cell.background.image = nil
            updateCounter(amount: -1)
            selectedBalls.removeAll(where: {$0 == availableBalls[indexPath.item]})
            applyButton.isEnabled = false
        }
        else {
            if cell.locked {
                if currentCurrency >= 500 {
                    print("Unlocking \(availableBalls[indexPath.item])")
                    updateCurrency(amount: -500)
                    var data = getUserData()
                    data.lockedBalls.removeAll(where: {$0 == availableBalls[indexPath.item]})
                    setUserData(userData: data)
                    cell.lockedImage.image = nil
                    cell.locked = false
                }
                else {
                    notification.setTitle("You don't have enough money", for: .normal)
                }
            }
            else {
                if selectedBallsCounter == 6 {
                    notification.setTitle("Six balls already selected", for: .normal)
                }
                else {
                    cell.chosen.toggle()
                    cell.background.image = UIImage(named: "selected")
                    updateCounter(amount: 1)
                    selectedBalls.append(availableBalls[indexPath.item])
                    if selectedBallsCounter == 6 {
                        applyButton.isEnabled = true
                    }
                }
            }
        }
        print(selectedBalls)
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
//       return CGSize(width: 100.0, height: 100.0)
        let width  = (view.frame.width-20)/3
        return CGSize(width: width, height: width)
    }
    
    func updateCounter(amount: Int) {
        selectedBallsCounter += amount
        selectedBallsCounterLabel.text = "\(selectedBallsCounter)"
    }
    
    func updateCurrency(amount: Int) {
        setCurrency(amount: -500)
        currentCurrency = getCurrency()
        currentCurrencyLabel.setTitle("\(currentCurrency)", for: .normal)
    }
    
    @IBAction func applyChanges(_ sender: UIButton) {
        var data = getUserData()
        data.selectedBalls = selectedBalls
        setUserData(userData: data)
    }
    
}
