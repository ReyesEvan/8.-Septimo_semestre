//
//  GameViewController.swift
//  MasterMind
//
//  Created by Carlos Andrés Reyes Evangelista in UDLAP19 on 10/5/19.
//  Copyright © 2019 UDLAP19. All rights reserved.
//

import Foundation
import UIKit
import AudioToolbox

class GameViewController: UIViewController {
    /* Outlets */
    @IBOutlet weak var ballsStack: UIStackView!
    @IBOutlet weak var attemptView: UIView!
    @IBOutlet weak var attemptsStack: UIStackView!
    @IBOutlet weak var enigmaStack: UIStackView!
    @IBOutlet weak var resultView: UIImageView!
    @IBOutlet weak var playAgainButton: UIButton!
    @IBOutlet weak var mainMenuButton: UIButton!
    @IBOutlet weak var resultLabel: UILabel!
    
    @IBOutlet weak var timerLabel: UILabel!
    @IBOutlet weak var matchMoneyLabel: UIButton!
    
    
    var attempts: [UIView] = []

    var currentAttemptCounter = 0
    var currentBallCounter = 0
    var currentAttemptView: UIView = UIView()
    var currentBallsPlaceholders: [UIImageView] = []
    var currentHintsView = UIImageView()
    var currentHintsStack = UIStackView()
    var currentHintsPlaceholders: [UIImageView] = []
    var currentlySelectedBalls = Array(repeating: -1, count: 4)
    var enigmaView: [UIImageView] = []

    let ballSelector = getSelectedBalls()
    
    var enigma = Array(repeating: -1, count: 4).map{_ in Int.random(in: 0...5)}
    
    var minutesCounter = 0
    var secondsCounter = 0
    var millisCounter = 0.0
    var timer = Timer()
    var matchCurrency = 0

    func updateCurrentAttempt() {
        currentAttemptView = attempts[currentAttemptCounter]

        let hintsView = currentAttemptView.subviews[0]
        let ballsView = currentAttemptView.subviews[1]

        currentHintsStack = hintsView.subviews.filter {
            $0 is UIStackView
        }.first as! UIStackView

        let ballsStack = ballsView.subviews.filter {
            $0 is UIStackView
        }.first as! UIStackView

        currentBallsPlaceholders = ballsStack.arrangedSubviews as! [UIImageView]

        currentBallsPlaceholders.forEach {
            $0.isUserInteractionEnabled = true
        }
        
        currentHintsPlaceholders.removeAll()
        for stack in (hintsView.subviews[1] as! UIStackView).arrangedSubviews {
            (stack as! UIStackView).arrangedSubviews.forEach {view in
                currentHintsPlaceholders.append(view as! UIImageView)
            }
        }
        
        currentHintsView = hintsView.subviews[0] as! UIImageView
        
        currentHintsStack.isUserInteractionEnabled = false
        
        currentlySelectedBalls = Array(repeating: -1, count: 4)
        
        currentAttemptCounter += 1
    }
    
    func verifyAttempt() -> (_: Int, _: Int) {
        var wrongPlaced = 0
        var wellPlaced = 0
        
        var temp = currentlySelectedBalls
        
        enigma.forEach {
            if temp.contains($0) {
                temp[temp.firstIndex(of: $0)!] = -1
                wrongPlaced += 1
            }
        }
        
        zip(enigma, currentlySelectedBalls).forEach {
            if ($0.0 == $0.1) {
                wellPlaced += 1
            }
        }
        
        wrongPlaced -= wellPlaced
        
        return (wellPlaced, wrongPlaced)
    }
    
    func endGame(result: String) {
        resultView.image = UIImage(named: result)
        resultLabel.text = result == "win" ? "You've won!" : "Better luck next time"
        enigmaView.forEach{$0.isHidden.toggle()}
        [playAgainButton, mainMenuButton].forEach { $0.setBackgroundImage(UIImage(named: "button"), for: .normal) }
        [resultView, playAgainButton, mainMenuButton, resultLabel].forEach{$0.isHidden.toggle()}
        
        ballsStack.arrangedSubviews.forEach{$0.isUserInteractionEnabled.toggle()}
    }

    func newGame() {
        enigma = Array(repeating: -1, count: 4).map{_ in Int.random(in: 0...5)}
        zip(enigmaView, enigma).forEach{
            $0.image = UIImage(named: ballSelector[$1])
            $0.isHidden = true
        }
        [resultView, playAgainButton, mainMenuButton, resultLabel].forEach{$0.isHidden.toggle()}
        ballsStack.arrangedSubviews.forEach{$0.isUserInteractionEnabled.toggle()}

        currentAttemptCounter = 0
        for _ in attempts {
            updateCurrentAttempt()
            currentBallsPlaceholders.forEach{$0.image = nil}
            currentHintsPlaceholders.forEach{$0.image = nil}
        }
        
        updateMoney(amount: -matchCurrency)
        
        currentAttemptCounter = 0
        updateCurrentAttempt()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        print(enigma)
        enigmaView = enigmaStack.arrangedSubviews as! [UIImageView]
        zip(enigmaView, enigma).forEach{
            $0.image = UIImage(named: ballSelector[$1])
            $0.isHidden.toggle()
        }

        let ballsSelector = ballsStack.arrangedSubviews

        for ballTuple in zip(ballsSelector, ballSelector) {
            (ballTuple.0 as! UIImageView).image = UIImage(named: ballTuple.1)
        }

        attempts = attemptsStack.arrangedSubviews
        attempts.reverse()

        for _ in attempts {
            updateCurrentAttempt()

            for ball in zip(currentBallsPlaceholders, 0...3) {
                let gesture = UITapGestureRecognizer(target: self, action: #selector(self.handleTapOnSelectedBall(_:)))
                gesture.name = "\(ball.1)"
                ball.0.addGestureRecognizer(gesture)
            }
            currentHintsStack.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(self.confirmAttempt(_:))))
        }

        currentAttemptCounter = 0
        updateCurrentAttempt()
        
        
        startTimer()
    }
    
    func updateMoney(amount: Int) {
        matchCurrency += amount
        matchMoneyLabel.setTitle("\(matchCurrency)", for: .normal)
    }
    
    func startTimer() {
        millisCounter = 0
        timer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(self.updateTimer), userInfo: nil, repeats: true)
    }
    
    func stopTimer() {
        timer.invalidate()
    }
    
    @objc func updateTimer() {
        millisCounter += 1
        secondsCounter = Int(millisCounter / 10) % 60
        minutesCounter = Int(millisCounter / 10 / 60)
        timerLabel.text = "\(String(format: "%02d", minutesCounter)):\(String(format: "%02d", secondsCounter))"
    }

    @objc func handleTapOnSelectedBall(_ sender: UITapGestureRecognizer? = nil) {
        let id = Int(sender!.name!)
        
        currentBallsPlaceholders[id!].image = nil
//        [self.currentBallsPlaceholders[Int(sender?.name ?? "0") ?? 0].setNeedsDisplay()]
        currentlySelectedBalls[id!] = -1
        currentHintsView.image = UIImage(named: "boardbackground")
        currentHintsStack.isUserInteractionEnabled = false
    }
    
    /**
     * This function will be executed when clicking on the
     * confirm attempt button (shown where the hints will be located)
     */
    @objc func confirmAttempt(_ sender: UITapGestureRecognizer? = nil) {
        // Restore the hints view and make it unclickable again
        currentHintsStack.isUserInteractionEnabled = false
        currentHintsView.image = UIImage(named: "boardbackground")

        // Stop listening to events on those balls
        currentBallsPlaceholders.forEach {$0.isUserInteractionEnabled = false}
        
        // Check the attempt against the original enigma
        let (wellPlaced, wrongPlaced) = verifyAttempt()

        // Provide visual feedback on the well and wrong placed balls
        currentHintsPlaceholders.prefix(wellPlaced).forEach {
            $0.image = UIImage(named: "wellPlaced") // TODO: Change it to actual well placed hints icon
        }
        currentHintsPlaceholders[wellPlaced..<wellPlaced + wrongPlaced].forEach {
            $0.image = UIImage(named: "wrongPlaced") // TODO: change it as well
        }

        // Check if the user has won, lost or the game is still ongoing
        if wellPlaced == 4 {
            print("Victory!")
            endGame(result: "win")
            stopTimer()
            updateMoney(amount: millisCounter < 3000 ? Int((3000 - millisCounter) / 10) : 0)
            setCurrency(amount: matchCurrency)
        }
        else {
            if currentAttemptCounter == 8 {
                endGame(result: "lose")
                stopTimer()
                updateMoney(amount: -5)
                setCurrency(amount: matchCurrency)
            }
            else {
                updateCurrentAttempt()
                updateMoney(amount: wellPlaced * 3)
                updateMoney(amount: wrongPlaced)
            }
        }
        
    }
    
    /**
     * This function is to be executed when clicking over any ball within the ball selector bar
     */
    @IBAction func handleBallClick(_ sender: UITapGestureRecognizer) {
//        SystemSoundID.playFile("beep", withExtension: "mp3")

        // Obtain the identifier (0...5) of the ball the user has clicked
        let id = Int(sender.view!.accessibilityIdentifier!)
        
        // Check the place where the ball must be colocated.
        // By default it is on the first -1 ocurrence
        let ballToPlace = currentlySelectedBalls.firstIndex(of: -1) ?? -1

        // If there is no place to place the ball then do not perform these operations
        // Otherwise, mark visually and programatically which ball is placed where
        if ballToPlace != -1 {
            currentBallsPlaceholders[ballToPlace].image = UIImage(named: ballSelector[id!])
            currentlySelectedBalls[ballToPlace] = id!
        }

        // Potentially after the previous conditional is performed, check if the attempt is full
        // if so, give the user the option to confirm their attempt
        if !currentlySelectedBalls.contains(-1) {
            currentHintsView.image = UIImage(named: "ok")
            currentHintsStack.isUserInteractionEnabled = true
        }
    }
    
    @IBAction func playAgainTap(_ sender: UIButton) {
        newGame()
        startTimer()
    }
}
