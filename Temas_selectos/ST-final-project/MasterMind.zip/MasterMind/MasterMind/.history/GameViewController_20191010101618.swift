//
//  GameViewController.swift
//  MasterMind
//
//  Created by UDLAP19 on 10/5/19.
//  Copyright © 2019 UDLAP19. All rights reserved.
//

import Foundation
import UIKit
import AudioToolbox

class GameViewController: UIViewController {
    /* Outlets */
    @IBOutlet weak var ballsStack: UIStackView!
    @IBOutlet weak var attemptView: UIView!
    @IBOutlet weak var attemptsStack: UIStackView!

    var attempts: [UIView] = []

    var currentAttemptCounter = 0
    var currentBallCounter = 0
    var currentAttemptView: UIView = UIView()
    var currentBallsPlaceholders: [UIImageView] = []
    var currentHintsPlaceholders: [UIImageView] = []

    let availableBalls = ["basketball", "soccer", "glass", "tennis", "pool", "golf"]

    func updateCurrentAttempt() {
        currentAttemptView = attempts[currentAttemptCounter]

        let hintsView = currentAttemptView.subviews[0]
        let ballsView = currentAttemptView.subviews[1]

        let hintsStack = hintsView.subviews.filter {
            $0 is UIStackView
        }.first as! UIStackView

        let ballsStack = ballsView.subviews.filter {
            $0 is UIStackView
        }.first as! UIStackView

        currentBallsPlaceholders = ballsStack.arrangedSubviews as! [UIImageView]

        /* for ball in ballsStack.arrangedSubviews as! [UIImageView] {
            ball.image = UIImage(named: "basketball")
        } */

        for stack in (hintsView.subviews[1] as! UIStackView).arrangedSubviews {
            (stack as! UIStackView).arrangedSubviews.forEach {view in
                currentHintsPlaceholders.append(view as! UIImageView)
            }
        }

        currentAttemptCounter += 1
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        attempts = attemptsStack.arrangedSubviews

        let ballsSelector = ballsStack.arrangedSubviews

        for ballTuple in zip(ballsSelector, availableBalls) {
            (ballTuple.0 as! UIImageView).image = UIImage(named: ballTuple.1)
        }

        updateCurrentAttempt()


        /* for attempt in attempts {
            updateCurrentAttempt()

            currentBallsPlaceholders.forEach{$0.image = UIImage(named: "basketball")}
            currentHintsPlaceholders.forEach{$0.image = UIImage(named: "basketball")}
        } */

    }


    @IBAction func handleBallClick(_ sender: UITapGestureRecognizer) {
        SystemSoundID.playFile("beep", withExtension: "mp3")
        print("asd \(sender.view?.accessibilityIdentifier ?? "nid")")
        currentBallsPlaceholders[currentBallCounter].image =
    }




}
