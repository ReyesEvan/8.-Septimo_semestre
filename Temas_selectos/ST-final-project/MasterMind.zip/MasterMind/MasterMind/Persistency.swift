//
//  Persistency.swift
//  MasterMind
//
//  Created by Carlos Andrés Reyes Evangelista in UDLAP19 on 10/5/19.
//  Copyright © 2019 UDLAP19. All rights reserved.
//

import Foundation


struct UserData: Codable {
    var currency: Int
    var selectedBalls: [String]
    var availableBalls: [String]
    var lockedBalls: [String]
}

let userDataURL = URL(fileURLWithPath: "UserData", relativeTo: FileManager.documentDirectoryURL).appendingPathExtension("plist")


func getUserData() -> UserData {
    let plistDecoder = PropertyListDecoder()
    
    do {
        let data = try Data.init(contentsOf: userDataURL)
        
        return try plistDecoder.decode(UserData.self, from: data)
    } catch { print(error) }
    return UserData(currency: 0, selectedBalls: [], availableBalls: [], lockedBalls: [])
}

func setUserData(userData: UserData) {
    let plistEncoder = PropertyListEncoder()
    plistEncoder.outputFormat = .xml
    
    do {
        let plistData = try plistEncoder.encode(userData)
        try plistData.write(to: userDataURL)
    } catch { print(error)}
}

func getCurrency() -> Int {
    return getUserData().currency
}

func getSelectedBalls() -> [String] {
    return getUserData().selectedBalls
}

func getLockedBalls() -> [String] {
    return getUserData().lockedBalls
}

func getAvailableBalls() -> [String] {
    return getUserData().availableBalls
}

func setCurrency(amount: Int) {
    var data = getUserData()
    data.currency += amount
    setUserData(userData: data)
}
