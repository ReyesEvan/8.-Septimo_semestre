//
//  ViewController.swift
//  MasterMind
//
//  Created by Carlos Andrés Reyes Evangelista in UDLAP19 on 10/5/19.
//  Copyright © 2019 UDLAP19. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var currentCurrency: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print(userDataURL)
        
        var data = getUserData()
        
        if data.availableBalls.isEmpty || data.selectedBalls.isEmpty {
            data.availableBalls = ["basketball", "soccer", "glass", "tennis", "pool", "golf", "baseball", "volleyball", "dodgeball", "waterpolo", "squash", "bowling"]
            data.selectedBalls = ["basketball", "soccer", "glass", "tennis", "pool", "golf"]
            data.lockedBalls = ["volleyball", "dodgeball", "waterpolo", "squash", "bowling"]
        }
        
        setUserData(userData: data)
        
        currentCurrency.setTitle("\(data.currency)", for: .normal)
    }
}

