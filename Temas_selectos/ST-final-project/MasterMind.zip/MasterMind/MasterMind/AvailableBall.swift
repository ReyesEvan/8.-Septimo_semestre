//
//  AvailableBall.swift
//  MasterMind
//
//  Created by Carlos Andrés Reyes Evangelista in UDLAP19 on 10/5/19.
//  Copyright © 2019 UDLAP19. All rights reserved.
//

import UIKit

class AvailableBall: UICollectionViewCell {
    @IBOutlet weak var background: UIImageView!
    @IBOutlet weak var ball: UIImageView!
    @IBOutlet weak var lockedImage: UIImageView!
    
    var chosen: Bool = false
    var locked: Bool = false
}
