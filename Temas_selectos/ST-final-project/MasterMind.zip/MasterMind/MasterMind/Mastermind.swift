//
//  Mastermind.swift
//  MasterMind
//
//  Created by UDLAP19 on 12/2/19.
//  Copyright © 2019 UDLAP19. All rights reserved.
//

import Foundation
import UIKit

//var selectedBalls = getSelectedBalls()

let availableBalls = getAvailableBalls()
